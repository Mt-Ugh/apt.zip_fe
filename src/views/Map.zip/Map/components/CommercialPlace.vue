<template>
  <div class="commercial-place">
    <button
      v-for="item in categories"
      :key="item.label"
      class="category-btn"
      @click="$emit('select', item.type)"
    >
      <img :src="item.icon" :alt="item.label" class="category-icon" />
      <span>{{ item.label }}</span>
    </button>
  </div>
</template>

<script setup>
const categories = [
  {
    type: 'food',
    label: '음식점',
    icon: new URL('@/assets/images/Map/Food.svg', import.meta.url).href,
  },
  {
    type: 'edu',
    label: '교육',
    icon: new URL('@/assets/images/Map/School.svg', import.meta.url).href,
  },
  {
    type: '보건의료',
    label: '병원',
    icon: new URL('@/assets/images/Map/Hospital.svg', import.meta.url).href,
  },
  {
    type: 'mart',
    label: '마트',
    icon: new URL('@/assets/images/Map/Shopping.svg', import.meta.url).href,
  },
  {
    type: 'bank',
    label: '은행',
    icon: new URL('@/assets/images/Map/Bank.svg', import.meta.url).href,
  },
]
</script>

<style scoped>
.commercial-place {
  position: absolute;
  top: 60px;
  right: 18px;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  z-index: 100;
}
.category-btn {
  display: flex;
  align-items: center;
  gap: 0.7em;
  background: #fff;
  border: 1px solid #eee;
  border-radius: 10px;
  padding: 8px 18px 8px 12px;
  font-size: 17px;
  color: #ff8000;
  font-weight: 600;
  cursor: pointer;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.07);
  transition: background 0.15s;
}
.category-btn:hover {
  background: #f7f7f7;
}
.category-icon {
  width: 26px;
  height: 26px;
}
</style>
